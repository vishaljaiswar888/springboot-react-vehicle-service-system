package com.cdac.dto;

public class CustomerRegistrationStatus extends Status
{

	private int customerId;

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	
}
