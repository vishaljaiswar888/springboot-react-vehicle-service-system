package com.cdac.dto;

public class Service_CenterRegistrationStatus extends Status
{

	private int service_center_id;

	public int getService_center_id() {
		return service_center_id;
	}

	public void setService_center_id(int service_center_id) {
		this.service_center_id = service_center_id;
	}

	

	
	
}
