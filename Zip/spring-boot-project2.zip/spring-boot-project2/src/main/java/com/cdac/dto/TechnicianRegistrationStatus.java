package com.cdac.dto;

public class TechnicianRegistrationStatus extends Status
{

	private int technician_id;

	public int getTechnician_id() {
		return technician_id;
	}

	public void setTechnician_id(int technician_id) {
		this.technician_id = technician_id;
	}

	
	
}
