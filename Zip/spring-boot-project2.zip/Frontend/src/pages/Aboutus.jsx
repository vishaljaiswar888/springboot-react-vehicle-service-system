import React from 'react';
import '../style/aboutUs.css'; 
import 'bootstrap/dist/css/bootstrap.min.css'; 
import { Link } from "react-router-dom";


const Aboutus = () => {
  return (
   

<section id="team" className="team section-bg">
<div className="container" data-aos="fade-up">
    <div className="section-title">
        <h2>CareZone-Team</h2>
        <p className='teamp'>
            Welcome to our vehicle serving system application. We are dedicated to providing top-notch services for all your vehicle needs.Our team of experts is committed to ensuring your vehicles run smoothly and efficiently.Feel free to contact us if you have any questions or inquiries about our services.
        </p>
    </div>
    <div className="row">
        {/* Member 1 */}
        <div className="col-lg-6 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="200">
            <div className="member d-flex align-items-start">
                <div className="pic"><img src="#" className="img-fluid" alt="" /></div>
                <div className="member-info">
                    <h4>Mayur</h4>
                    <span>Member-1</span>
                    <p className='teamp'>Pursuing Post Graution Diploma In Advanced Computing</p>
                    <div className="social">
                        <Link to=""><i className="ri-twitter-fill"></i></Link>
                        <Link to=""><i className="ri-facebook-fill"></i></Link>
                        <Link to=""><i className="ri-instagram-fill"></i></Link>
                        <Link to=""><i className="ri-linkedin-box-fill"></i></Link>

                    </div>
                </div>
            </div>
        </div>
        {/* Member 2 */}
        <div className="col-lg-6" data-aos="fade-up" data-aos-delay="100">
            <div className="member d-flex align-items-start">
                <div className="pic"><img src="#" className="img-fluid" alt="" /></div>
                <div className="member-info">
                    <h4>Vishal</h4>
                    <span>Member-2</span>
                    <p className='teamp'>Pursuing Post Graution Diploma In Advanced Computing</p>
                    <div className="social">
                        <Link to=""><i className="ri-twitter-fill"></i></Link>
                        <Link to=""><i className="ri-facebook-fill"></i></Link>
                        <Link to=""><i className="ri-instagram-fill"></i></Link>
                        <Link to=""><i className="ri-linkedin-box-fill"></i></Link>
                    </div>
                </div>
            </div>
        </div>
        {/* Member 3 */}
        <div className="col-lg-6 mt-4" data-aos="fade-up" data-aos-delay="300">
            <div className="member d-flex align-items-start">
                <div className="pic"><img src="#" className="img-fluid" alt="" /></div>
                <div className="member-info">
                    <h4>Pratik</h4>
                    <span>Member-3</span>
                    <p className='teamp'>Pursuing Post Graution Diploma In Advanced Computing</p>
                    <div className="social">
                        <Link to=""><i className="ri-twitter-fill"></i></Link>
                        <Link to=""><i className="ri-facebook-fill"></i></Link>
                        <Link to=""><i className="ri-instagram-fill"></i></Link>
                        <Link to=""><i className="ri-linkedin-box-fill"></i></Link>
                    </div>
                </div>
            </div>
        </div>
        {/* Member 4 */}
        <div className="col-lg-6 mt-4" data-aos="fade-up" data-aos-delay="400">
            <div className="member d-flex align-items-start">
                <div className="pic"><img src="#" className="img-fluid" alt="" /></div>
                <div className="member-info">
                    <h4>Hariom</h4>
                    <span>Member-4</span>
                    <p className='teamp'>Pursuing Post Graution Diploma In Advanced Computing</p>
                    <div className="social">
                        <Link to=""><i className="ri-twitter-fill"></i></Link>
                        <Link to=""><i className="ri-facebook-fill"></i></Link>
                        <Link to=""><i className="ri-instagram-fill"></i></Link>
                        <Link to=""><i className="ri-linkedin-box-fill"></i></Link>
                    </div>
                </div>
            </div>
        </div>
        {/* Member 5 */}
        <div className="col-lg-6 mt-4" data-aos="fade-up" data-aos-delay="500">
            <div className="member d-flex align-items-start">
                <div className="pic"><img src="#" className="img-fluid" alt="" /></div>
                <div className="member-info">
                    <h4>Mrunali</h4>
                    <span>Member-5</span>
                    <p className='teamp'>Pursuing Post Graution Diploma In Advanced Computing</p>
                    <div className="social">
                        <Link to=""><i className="ri-twitter-fill"></i></Link>
                        <Link to=""><i className="ri-facebook-fill"></i></Link>
                        <Link to=""><i className="ri-instagram-fill"></i></Link>
                        <Link to=""><i className="ri-linkedin-box-fill"></i></Link>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</section>
    
  );
};

export default Aboutus;
